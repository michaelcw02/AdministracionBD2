conn sistema/sistema                                                                                
spool C:\bd2\PRACTICA3_6PM_MICHAEL_CHEN\drop_secuencia.log                                          
                                                                                                    
DROP SEQUENCE SEC_CON01;                                                                            
DROP SEQUENCE SEC_PLA01;                                                                            
spool off;                                                                                          
EXIT                                                                                                
                                                                                                    
