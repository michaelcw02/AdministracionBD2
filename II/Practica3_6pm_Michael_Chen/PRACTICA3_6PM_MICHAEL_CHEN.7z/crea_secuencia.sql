conn sistema/sistema                                                                                
spool C:\bd2\PRACTICA3_6PM_MICHAEL_CHEN\crea_secuencia.log                                          
                                                                                                    
CREATE SEQUENCE SEC_PLA01 START WITH 1 INCREMENT BY 1;                                              
CREATE SEQUENCE SEC_CON01 START WITH 1 INCREMENT BY 1;                                              
spool off;                                                                                          
EXIT                                                                                                
                                                                                                    
