conn sistema/sistema                                                                                
spool C:\bd2\PRACTICA3_6PM_MICHAEL_CHEN\agregar_columna.log                                         
                                                                                                    
ALTER TABLE PLA01 ADD PRACTICA NUMBER;                                                              
ALTER TABLE CON01 ADD PRACTICA NUMBER;                                                              
spool off;                                                                                          
EXIT                                                                                                
                                                                                                    
