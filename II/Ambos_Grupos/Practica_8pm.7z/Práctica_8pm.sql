Práctica 8pm
------------

1) La captura del usuario origen debe ser en mayuscula
cuando valida el owner en el Diccionario de Datos.
cambie el codigo para que permita si el usuario origen
lo digitan en minuscula en el DD lo  busque en mayuscula.

UPPER(variable1)


2) Por 10 puntos extra en quiz. Guillermo Castro 10ptos.
luego de clonar las tablas.
haga un script dinámico que genere un select count(*) por cada
tabla del usuario destino
Ej:  
select count(*) from HUGO.CON01;
select count(*) from HUGO.CON02;
..
ejecuta_conteo.sql
y que se genere spool ejecuta_conteo.log // OPCIONAL
--agregar .bat




















3) Por 25 puntos.  sin asignar!!
conectado como system.
Por cada tabla creada del usuario destino crear
script que renombre la tabla con un SUFIJO que se reciba por parámetro
ej:

Captura Sufijo: a2
ej:
alter table HUGO.CON01 rename to CON01a2;
..
.


















por 30 puntos  Ramirez Gomez. Jose Pablo.
4) conectado como system. para el usuario destino
capturar el nombre de la columna  a agregar // tipo es fijo number
para las tablas del usuario destino
agregar una columna "___ number" a cada tabla destino
ej:
Captura nombre campo:  campo1
alter table HUGO.CON02 add (campo1 number);
..
..
con spool que funcione bien!!!



















