conn system/root                                                                                    
create table HUGO.CON01 as                                                                          
select * from SISTEMA.CON01;                                                                        
                                                                                                    
create table HUGO.CON02 as                                                                          
select * from SISTEMA.CON02;                                                                        
                                                                                                    
create table HUGO.CON03 as                                                                          
select * from SISTEMA.CON03;                                                                        
                                                                                                    
create table HUGO.PLA01 as                                                                          
select * from SISTEMA.PLA01;                                                                        
                                                                                                    
create table HUGO.PLA02 as                                                                          
select * from SISTEMA.PLA02;                                                                        
                                                                                                    
create table HUGO.PLA03 as                                                                          
select * from SISTEMA.PLA03;                                                                        
                                                                                                    
create table HUGO.PLA04 as                                                                          
select * from SISTEMA.PLA04;                                                                        
                                                                                                    
create table HUGO.PLA05 as                                                                          
select * from SISTEMA.PLA05;                                                                        
                                                                                                    
host pause                                                                                          
exit                                                                                                
