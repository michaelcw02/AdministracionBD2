conn system/root                                                                                    
spool C:\bd2\ejecuta_conteo.log                                                                     
select count(*) from HUGO.CON01;                                                                    
select count(*) from HUGO.CON02;                                                                    
select count(*) from HUGO.CON03;                                                                    
select count(*) from HUGO.PLA01;                                                                    
select count(*) from HUGO.PLA02;                                                                    
select count(*) from HUGO.PLA03;                                                                    
select count(*) from HUGO.PLA04;                                                                    
select count(*) from HUGO.PLA05;                                                                    
spool off                                                                                           
host pause                                                                                          
exit                                                                                                
