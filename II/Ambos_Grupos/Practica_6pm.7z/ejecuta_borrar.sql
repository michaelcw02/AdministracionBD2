conn system/root                                                                                    
spool C:\bd2\ejecuta_borrar.log                                                                     
drop table HUGO.CON01;                                                                              
drop table HUGO.CON02;                                                                              
drop table HUGO.CON03;                                                                              
drop table HUGO.PLA01;                                                                              
drop table HUGO.PLA02;                                                                              
drop table HUGO.PLA03;                                                                              
drop table HUGO.PLA04;                                                                              
drop table HUGO.PLA05;                                                                              
spool off                                                                                           
host pause                                                                                          
exit                                                                                                
