--
conn test/test

--crear table
drop table tab1;


exit
