--
conn test/test

--crear table
create table tab1(a number);


exit
