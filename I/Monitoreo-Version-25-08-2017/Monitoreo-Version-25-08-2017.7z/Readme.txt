Para los que hagan proyecto, pueden copiar de la carpeta donde esté el NOTEPAD++
el archivo .exe y los dos archivos .DLL en la carpeta de su proyecto (NppShell_06.dll,notepad++.exe,SciLexer.dll)
(por ejemplo yo las copié en C:\BD2\)
y llamar el notepad en el .BAT así:
C:\bd2\notepad++.exe C:\bd2\cod_fuente_out.sql
(yo lo hice en cod_fuente.bat, favor revisan)
Favor prueban esto anterior.

Ya que el NOTEPAD++ puede instarse en carpetas distintas según lenguanje Windows (Inglés o Español)
Para que funcione correcto el Avance #1 (si hace en llamado de los .log con Notepad++)

Para probar el programa, luego de copiar los archivos de NOTEPAD
#1 Correr script : 2017-08-25-cod-fuente.sql
#2 Correr Monitoreo.BAT
#3 Seleccionar Opción #5 del Menú (Resp. Cod. Fuente.)
   (La opción #3 debería llamar el Notepad y vería el script donde se crea la funcion y el procedimiento)
