--crear hr3
drop user hr3 cascade;
create user hr3 identified by hr321;
grant dba to hr3;
exit